import { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "customer" | "admin";
    } & DefaultSession["user"];
  }

  interface User {
    role?: "customer" | "admin";
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    uid?: string;
    role?: "customer" | "admin";
  }
}
